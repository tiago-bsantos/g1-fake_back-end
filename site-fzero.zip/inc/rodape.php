<footer id="rodape">
	<p>&copy; Copyright 2015-2016 Organizações Tabajara | Política de Privacidade</p> 
</footer>
</div>
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="slick/slick.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>