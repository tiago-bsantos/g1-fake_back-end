<?php include "inc/cabecalho.php"; ?>
<main>
    <h2>Acesso negado</h2>
    <p>O usuário e/ou senha não foram encontrados no sistema.</p>
    <p><a href="entrar.php">Voltar</a></p>
</main>
<?php include "inc/rodape.php"; ?>