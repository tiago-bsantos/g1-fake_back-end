<?php
include "../inc/logica-acesso.php"; 
logout();
?>
