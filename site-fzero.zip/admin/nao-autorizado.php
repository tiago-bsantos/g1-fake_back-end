<?php require_once "../inc/admin-cabecalho.php"; ?>
<main>
    <h2>Ácesso não autorizado</h2>
    <p>Você não possui permissão para acessar esta página.</p>
    <p><a href="index.php">Voltar</a></p>
</main>
<?php require_once "../inc/admin-rodape.php"; ?>